package com.aitrich.android.resultpasssing;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SendResult extends Activity {
	EditText send_Text;
	 @Override
		protected void onCreate(Bundle savedInstanceState)
	 {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.send_result);
	        Bundle extras = getIntent().getExtras();
	        
	        //get data send that we send along with intent from the bundle.
	        //You should use the same key that we used to put data
	        String message = extras.getString("message");
	        TextView recv_Text = (TextView)findViewById(R.id.msgRecv);
	        recv_Text.setText(message);
	        send_Text = (EditText)findViewById(R.id.replyText);
	    }

	    public void toMainActivity(View view)
	    {
	    	String message = send_Text.getText().toString();
	    	setResult(RESULT_OK, (new Intent(SendResult.this, RecieveResult.class)).setAction(message));
	    	finish();
	    }
}
