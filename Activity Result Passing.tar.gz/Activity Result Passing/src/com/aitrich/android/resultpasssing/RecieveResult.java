package com.aitrich.android.resultpasssing;

import android.app.Activity;
import android.content.Intent;
import android.text.Editable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class RecieveResult extends Activity {
EditText message;
EditText replyMessage;
String message_Text;
    @Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.receive_result);
        message = (EditText)findViewById(R.id.msgText);
        replyMessage = (EditText)findViewById(R.id.replyText);
        Button next = (Button)findViewById(R.id.Send);
    }

    @Override
	protected void onActivityResult(int requestCode, int resultCode,
		Intent data) {
        // You can use the requestCode to select between multiple child
        // activities you may have started.  Here there is only one thing
        // we launch.
        if (requestCode == GET_CODE) {
        	String reply = (String)data.getAction();
        	replyMessage.setText(reply);
        }
    }

    // Definition of the one requestCode we use for receiving resuls.
    static final private int GET_CODE = 0;
    public void toNext(View view)
       {
    		//Get the message entered to a string to send
        	message_Text = message.getText().toString();
            // Start the activity whose result we want to retrieve.  The
            // result will come back with request code GET_CODE.
            Intent intent = new Intent(RecieveResult.this, SendResult.class);
            //we can pass data along with intent as key-value pair
            intent.putExtra("message", message_Text);
            startActivityForResult(intent, GET_CODE);
       }      
}

