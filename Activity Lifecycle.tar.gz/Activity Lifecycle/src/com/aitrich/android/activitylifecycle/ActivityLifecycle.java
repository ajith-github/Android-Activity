package com.aitrich.android.activitylifecycle;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ActivityLifecycle extends Activity {
	/** Called when the activity is first created. */

	private final static String TAG = "ActivityLifecycle";
	TextView textViewLog;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lifecycle);
		Log.i(TAG, "On Create");
		textViewLog=(TextView) findViewById(R.id.tvLog);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		Log.i(TAG, "On Destroy");
		textViewLog.append("Executed onDestroy()!!\n");
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		textViewLog.append("Executed onPause()!!\n");
		Log.i(TAG, "On Pause");
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		textViewLog.append("Executed onRestart()!!\n");
		Log.i(TAG, "On Restart");
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		textViewLog.append("Executed onResume()!!\n");
		Log.i(TAG, "On Resume");
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		textViewLog.append("Executed onStart()!!\n");
		Log.i(TAG, "On Start");
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		textViewLog.append("Executed onStop()!!\n");
		Log.i(TAG, "On Stop");
	}
}